#ifndef __included_hpp_af_xdp_api_json
#define __included_hpp_af_xdp_api_json

#include <vapi/vapi.hpp>
#include <vapi/af_xdp.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_af_xdp_create>(vapi_msg_af_xdp_create *msg)
{
  vapi_msg_af_xdp_create_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_af_xdp_create>(vapi_msg_af_xdp_create *msg)
{
  vapi_msg_af_xdp_create_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_af_xdp_create>()
{
  return ::vapi_msg_id_af_xdp_create; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_af_xdp_create>>()
{
  return ::vapi_msg_id_af_xdp_create; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_af_xdp_create()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_af_xdp_create>(vapi_msg_id_af_xdp_create);
}

template <> inline vapi_msg_af_xdp_create* vapi_alloc<vapi_msg_af_xdp_create>(Connection &con)
{
  vapi_msg_af_xdp_create* result = vapi_alloc_af_xdp_create(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_af_xdp_create>;

template class Request<vapi_msg_af_xdp_create, vapi_msg_af_xdp_create_reply>;

using Af_xdp_create = Request<vapi_msg_af_xdp_create, vapi_msg_af_xdp_create_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_af_xdp_create_v2>(vapi_msg_af_xdp_create_v2 *msg)
{
  vapi_msg_af_xdp_create_v2_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_af_xdp_create_v2>(vapi_msg_af_xdp_create_v2 *msg)
{
  vapi_msg_af_xdp_create_v2_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_af_xdp_create_v2>()
{
  return ::vapi_msg_id_af_xdp_create_v2; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_af_xdp_create_v2>>()
{
  return ::vapi_msg_id_af_xdp_create_v2; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_af_xdp_create_v2()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_af_xdp_create_v2>(vapi_msg_id_af_xdp_create_v2);
}

template <> inline vapi_msg_af_xdp_create_v2* vapi_alloc<vapi_msg_af_xdp_create_v2>(Connection &con)
{
  vapi_msg_af_xdp_create_v2* result = vapi_alloc_af_xdp_create_v2(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_af_xdp_create_v2>;

template class Request<vapi_msg_af_xdp_create_v2, vapi_msg_af_xdp_create_v2_reply>;

using Af_xdp_create_v2 = Request<vapi_msg_af_xdp_create_v2, vapi_msg_af_xdp_create_v2_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_af_xdp_create_reply>(vapi_msg_af_xdp_create_reply *msg)
{
  vapi_msg_af_xdp_create_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_af_xdp_create_reply>(vapi_msg_af_xdp_create_reply *msg)
{
  vapi_msg_af_xdp_create_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_af_xdp_create_reply>()
{
  return ::vapi_msg_id_af_xdp_create_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_af_xdp_create_reply>>()
{
  return ::vapi_msg_id_af_xdp_create_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_af_xdp_create_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_af_xdp_create_reply>(vapi_msg_id_af_xdp_create_reply);
}

template class Msg<vapi_msg_af_xdp_create_reply>;

using Af_xdp_create_reply = Msg<vapi_msg_af_xdp_create_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_af_xdp_create_v2_reply>(vapi_msg_af_xdp_create_v2_reply *msg)
{
  vapi_msg_af_xdp_create_v2_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_af_xdp_create_v2_reply>(vapi_msg_af_xdp_create_v2_reply *msg)
{
  vapi_msg_af_xdp_create_v2_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_af_xdp_create_v2_reply>()
{
  return ::vapi_msg_id_af_xdp_create_v2_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_af_xdp_create_v2_reply>>()
{
  return ::vapi_msg_id_af_xdp_create_v2_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_af_xdp_create_v2_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_af_xdp_create_v2_reply>(vapi_msg_id_af_xdp_create_v2_reply);
}

template class Msg<vapi_msg_af_xdp_create_v2_reply>;

using Af_xdp_create_v2_reply = Msg<vapi_msg_af_xdp_create_v2_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_af_xdp_delete>(vapi_msg_af_xdp_delete *msg)
{
  vapi_msg_af_xdp_delete_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_af_xdp_delete>(vapi_msg_af_xdp_delete *msg)
{
  vapi_msg_af_xdp_delete_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_af_xdp_delete>()
{
  return ::vapi_msg_id_af_xdp_delete; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_af_xdp_delete>>()
{
  return ::vapi_msg_id_af_xdp_delete; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_af_xdp_delete()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_af_xdp_delete>(vapi_msg_id_af_xdp_delete);
}

template <> inline vapi_msg_af_xdp_delete* vapi_alloc<vapi_msg_af_xdp_delete>(Connection &con)
{
  vapi_msg_af_xdp_delete* result = vapi_alloc_af_xdp_delete(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_af_xdp_delete>;

template class Request<vapi_msg_af_xdp_delete, vapi_msg_af_xdp_delete_reply>;

using Af_xdp_delete = Request<vapi_msg_af_xdp_delete, vapi_msg_af_xdp_delete_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_af_xdp_delete_reply>(vapi_msg_af_xdp_delete_reply *msg)
{
  vapi_msg_af_xdp_delete_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_af_xdp_delete_reply>(vapi_msg_af_xdp_delete_reply *msg)
{
  vapi_msg_af_xdp_delete_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_af_xdp_delete_reply>()
{
  return ::vapi_msg_id_af_xdp_delete_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_af_xdp_delete_reply>>()
{
  return ::vapi_msg_id_af_xdp_delete_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_af_xdp_delete_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_af_xdp_delete_reply>(vapi_msg_id_af_xdp_delete_reply);
}

template class Msg<vapi_msg_af_xdp_delete_reply>;

using Af_xdp_delete_reply = Msg<vapi_msg_af_xdp_delete_reply>;
}
#endif
