#ifndef included_ethernet_types_api_types_h
#define included_ethernet_types_api_types_h
#define VL_API_ETHERNET_TYPES_API_VERSION_MAJOR 1
#define VL_API_ETHERNET_TYPES_API_VERSION_MINOR 0
#define VL_API_ETHERNET_TYPES_API_VERSION_PATCH 0
/* Imported API files */
typedef u8 vl_api_mac_address_t[6];

#endif
