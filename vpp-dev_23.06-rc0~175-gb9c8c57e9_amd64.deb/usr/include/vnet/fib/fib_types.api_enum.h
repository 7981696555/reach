#ifndef included_fib_types_api_enum_h
#define included_fib_types_api_enum_h
typedef enum {
   VL_MSG_FIB_TYPES_LAST
} vl_api_fib_types_enum_t;
#endif
