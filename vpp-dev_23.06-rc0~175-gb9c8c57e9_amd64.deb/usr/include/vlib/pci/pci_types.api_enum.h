#ifndef included_pci_types_api_enum_h
#define included_pci_types_api_enum_h
typedef enum {
   VL_MSG_PCI_TYPES_LAST
} vl_api_pci_types_enum_t;
#endif
